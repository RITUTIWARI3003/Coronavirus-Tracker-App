package com.springboot.todo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.todo.dto.TodoDTO;
import com.springboot.todo.service.impl.TodoServiceImpl;

import lombok.AllArgsConstructor;

@RestController
@RequestMapping("api/todo")
@AllArgsConstructor
public class TodoController {
	
	private TodoServiceImpl todoServiceImpl;
	
	
	@PostMapping
	public ResponseEntity<TodoDTO> addTodos(@RequestBody TodoDTO todoDTO){
		
		TodoDTO addTodoDTO = this.todoServiceImpl.addTodoDTO(todoDTO);
		
		return new ResponseEntity<>(addTodoDTO,HttpStatus.CREATED);
		
	}
	
	@GetMapping("/{todoId}")
	public ResponseEntity<TodoDTO> getTodos(@PathVariable("todoId") Long id){
		
		TodoDTO todoDTO = this.todoServiceImpl.getTodo(id);
		
		return new ResponseEntity<>(todoDTO,HttpStatus.OK);
		
	}
	

}
