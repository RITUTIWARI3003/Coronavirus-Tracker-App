package com.springboot.todo.service;

import com.springboot.todo.dto.TodoDTO;

public interface TodoService {
	
	TodoDTO addTodoDTO(TodoDTO todoDTO);
	TodoDTO getTodo(Long id);
	
	

}
