package com.springboot.todo.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.springboot.todo.dto.TodoDTO;
import com.springboot.todo.entity.Todo;
import com.springboot.todo.repository.TodoRepository;
import com.springboot.todo.service.TodoService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class TodoServiceImpl implements TodoService {
	
	private TodoRepository todoRepository;
	private ModelMapper modelMapper;

	@Override
	public TodoDTO addTodoDTO(TodoDTO todoDTO) {
		// TodoDto to todo
		
		Todo todo = modelMapper.map(todoDTO, Todo.class);
				
		
		// save todo
		
		Todo savedTodo = this.todoRepository.save(todo);
	
		//todo to tododto
		
		TodoDTO savedTodoDTO = modelMapper.map(savedTodo, TodoDTO.class);
		
		return savedTodoDTO;
	}

	@Override
	public TodoDTO getTodo(Long id) {
		
		Todo todo = this.todoRepository.findById(id).get();
		
		return modelMapper.map(todo,TodoDTO.class);
	}

}
