package com.springboot.department;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRestfulWebServices1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
