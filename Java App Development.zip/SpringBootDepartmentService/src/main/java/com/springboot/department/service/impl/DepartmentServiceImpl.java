package com.springboot.department.service.impl;

import org.springframework.stereotype.Service;

import com.springboot.department.dto.DepartmentDTO;
import com.springboot.department.entity.Department;
import com.springboot.department.repository.DepartmentRepository;
import com.springboot.department.service.DepartmentService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {
	
	private DepartmentRepository departmentRepository;

	@Override
	public DepartmentDTO saveDepartment(DepartmentDTO departmentDTO) {
		//convert Department DTO to JPA 
		Department department = new Department(
				                  departmentDTO.getId(),
				                  departmentDTO.getDepartmentName(),
				                  departmentDTO.getDepartmentDescription(),
				                  departmentDTO.getDepartmentCode());
		Department savedDepartment = departmentRepository.save(department);
		
		//Convert JPA to DTO
		DepartmentDTO savedDepartmentDTO = new DepartmentDTO(
				                              savedDepartment.getId(),
				                              savedDepartment.getDepartmentName(),
				                              savedDepartment.getDepartmentDescription(),
				                              savedDepartment.getDepartmentCode());
		
		return savedDepartmentDTO;
		
	}

	@Override
	public DepartmentDTO getDepartmentCode(String departmentCode) {
		Department department = departmentRepository.findByDepartmentCode(departmentCode);
		
		//Convert JPA to DTO
				DepartmentDTO savedDepartmentDTO = new DepartmentDTO(
						                              department.getId(),
						                              department.getDepartmentName(),
						                              department.getDepartmentDescription(),
						                              department.getDepartmentCode());
				
				return savedDepartmentDTO;
		
		
	}

}
