package com.springboot.department.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.department.dto.DepartmentDTO;
import com.springboot.department.service.DepartmentService;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;

@Tag(
		name = "Department Controller")
@RestController
@RequestMapping("api/department")
@AllArgsConstructor
public class DepartmentController {
	
	private DepartmentService departmentService;
	
	@PostMapping
	public ResponseEntity<DepartmentDTO> createUser(@RequestBody DepartmentDTO departmentDTO){
		DepartmentDTO dpmntDto = departmentService.saveDepartment(departmentDTO);
		return new ResponseEntity<>(dpmntDto,HttpStatus.CREATED);
	}
	@GetMapping("{department-code}")
	public ResponseEntity<DepartmentDTO> getDepartment(@PathVariable("department-code") String departmentCode){
		DepartmentDTO departmentDTO = departmentService.getDepartmentCode(departmentCode);
		return new ResponseEntity<DepartmentDTO>(departmentDTO,HttpStatus.OK);
	}

}
