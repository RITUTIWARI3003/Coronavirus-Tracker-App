package com.springboot.department.service;

import com.springboot.department.dto.DepartmentDTO;

public interface DepartmentService {
	
	DepartmentDTO saveDepartment(DepartmentDTO departmentDTO);
	DepartmentDTO getDepartmentCode(String  departmentCode);
	

}
