package com.springboot.department;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@OpenAPIDefinition(
		info = @Info(
				title = "Department Service"))
@SpringBootApplication
public class SpringbootRestfulWebServices1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootRestfulWebServices1Application.class, args);
	}

}
