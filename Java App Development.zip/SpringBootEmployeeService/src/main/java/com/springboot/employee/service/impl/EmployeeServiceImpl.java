package com.springboot.employee.service.impl;

import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.springboot.employee.dto.APIResponseDTO;
import com.springboot.employee.dto.DepartmentDTO;
import com.springboot.employee.dto.EmployeeDTO;
import com.springboot.employee.entity.Employee;
import com.springboot.employee.repository.EmployeeRepository;
import com.springboot.employee.service.EmployeeService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeRepository employeeRepository;
	
	private WebClient webClient;
	//private RestTemplate restTemplate;

	@Override
	public EmployeeDTO saveEmployee(EmployeeDTO employeeDTO) {
		
		Employee employee = new Employee(
				                  employeeDTO.getId(),
				                  employeeDTO.getFirstName(),
				                  employeeDTO.getLastName(),
				                  employeeDTO.getEmail(),
				                  employeeDTO.getDepartmentCode());
		
		Employee savedEmployee = employeeRepository.save(employee);
		
		EmployeeDTO empDTO = new EmployeeDTO(
				savedEmployee.getId(),
				savedEmployee.getFirstName(),
				savedEmployee.getLastName(),
				savedEmployee.getEmail(),
				savedEmployee.getDeparmentCode());
		
		return empDTO;
	}
	
	// Using Rest Template 

//	@Override
//	public APIResponseDTO getEmployeeById(Long empId) {
//		Optional<Employee> optionalEmployee = employeeRepository.findById(empId);
//		Employee savedEmployee = optionalEmployee.get();
//		
//		ResponseEntity<DepartmentDTO> forEntity = restTemplate.getForEntity("http://localhost:8080/api/department/" + savedEmployee.getDeparmentCode(),
//				         DepartmentDTO.class);
//		DepartmentDTO departmentDTO = forEntity.getBody();
//		
//		EmployeeDTO employeeDTO = new EmployeeDTO(
//				savedEmployee.getId(),
//				savedEmployee.getFirstName(),
//				savedEmployee.getLastName(),
//				savedEmployee.getEmail(),
//				savedEmployee.getDeparmentCode());
//		
//		APIResponseDTO apiResponseDTO = new APIResponseDTO();
//		apiResponseDTO.setEmployee(employeeDTO);
//		apiResponseDTO.setDepartment(departmentDTO);
//		
//		return apiResponseDTO;
//	}
	
	//Using Web Client
	
	@Override
	public APIResponseDTO getEmployeeById(Long empId) {
		Optional<Employee> optionalEmployee = employeeRepository.findById(empId);
		Employee savedEmployee = optionalEmployee.get();
		 DepartmentDTO departmentDTO = webClient.get()
		          .uri("http://localhost:8080/api/department/" + savedEmployee.getDeparmentCode())
		          .retrieve()
		          .bodyToMono(DepartmentDTO.class)
		          .block();
		
		
		EmployeeDTO employeeDTO = new EmployeeDTO(
				savedEmployee.getId(),
				savedEmployee.getFirstName(),
				savedEmployee.getLastName(),
				
				savedEmployee.getEmail(),
				savedEmployee.getDeparmentCode());
		
		APIResponseDTO apiResponseDTO = new APIResponseDTO();
		apiResponseDTO.setEmployee(employeeDTO);
		apiResponseDTO.setDepartment(departmentDTO);
		
		return apiResponseDTO;
	}

}
