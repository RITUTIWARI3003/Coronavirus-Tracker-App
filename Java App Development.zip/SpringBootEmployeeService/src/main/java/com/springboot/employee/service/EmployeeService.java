package com.springboot.employee.service;

import com.springboot.employee.dto.APIResponseDTO;
import com.springboot.employee.dto.EmployeeDTO;

public interface EmployeeService {
	
	EmployeeDTO saveEmployee(EmployeeDTO employeeDTO);
	APIResponseDTO getEmployeeById(Long empId);

}
