package com.springboot.employee.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.employee.dto.APIResponseDTO;
import com.springboot.employee.dto.EmployeeDTO;
import com.springboot.employee.service.EmployeeService;

import lombok.AllArgsConstructor;

@RestController
@RequestMapping("api/employee")
@AllArgsConstructor
public class EmployeeController {
	
	private EmployeeService employeeService;
	
	@PostMapping
	public ResponseEntity<EmployeeDTO> createEmployee(@RequestBody EmployeeDTO employeeDTO){
		EmployeeDTO empDTO = employeeService.saveEmployee(employeeDTO);
		return new ResponseEntity<EmployeeDTO>(empDTO,HttpStatus.OK);
	}
	@GetMapping("{emp_id}")
	public ResponseEntity<APIResponseDTO> getEmployee(@PathVariable("emp_id") Long id){
		APIResponseDTO apiResponseDTO = employeeService.getEmployeeById(id);
		return new ResponseEntity<APIResponseDTO>(apiResponseDTO,HttpStatus.OK);
	}

}
